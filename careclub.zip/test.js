var today = new Date();
var d=new Date("2023-12-25")
if(d<today){
    console.log("invalid")
}
else{
    console.log("valid")
}
